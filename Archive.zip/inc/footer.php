		<div class="containter-fluid footer">
			<p style="text-color: #000; margin: 0px; font-family: 'Open Sans Condensed'; letter-spacing: 3px;">&copy;<?php echo date('Y'); ?> Tania Rosa Bindhoff</p>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
		<script src='//blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js'></script>
		<script src="js/bootstrap-image-gallery.min.js"></script>
	</body>
</html>